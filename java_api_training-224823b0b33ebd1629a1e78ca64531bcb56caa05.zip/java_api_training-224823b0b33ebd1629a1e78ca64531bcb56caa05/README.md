# java_api_training

![Build](https://github.com/abdelouahid-behar/java_api_training/actions/workflows/build.yml/badge.svg)
[![codecov](https://codecov.io/gh/abdelouahid-behar/java_api_training/branch/main/graph/badge.svg)](https://codecov.io/gh/abdelouahid-behar/java_api_training)
